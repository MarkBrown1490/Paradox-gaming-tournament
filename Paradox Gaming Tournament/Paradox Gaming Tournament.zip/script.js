const teams = [
  'Eclipse',
  'Los Frogones',
  'MaD Synergy',
  'Origin',
  'Oryx AetherFrost',
  'PG Bloodborn Legion',
  'PG Shenanigans Syndicate',
  'RAZE',
  'UG Sköll',
  'UG Vanguards'
];

// Generate all unique matchups (45 total for 10 teams)
const matches = [];
for (let i = 0; i < teams.length; i++) {
  for (let j = i + 1; j < teams.length; j++) {
    matches.push([teams[i], teams[j]]);
  }
}

function loadMatches() {
  const container = document.getElementById('matches');
  if (!container) return;

  matches.forEach((pair, index) => {
    const storedResult = localStorage.getItem(`match-result-${index}`) || "";
    const storedDate = localStorage.getItem(`match-date-${index}`) || "";

    const match = document.createElement('div');
    match.className = 'match';
    match.innerHTML = `
      <h3>Match ${index + 1}: ${pair[0]} vs ${pair[1]}</h3>
      <label>Date:
        <input type="date" id="match-date-${index}" value="${storedDate}" />
      </label>
      <label>Result:
        <select id="match-result-${index}">
          <option value="">-- Select Winner --</option>
          <option value="${pair[0]}" ${storedResult === pair[0] ? "selected" : ""}>${pair[0]}</option>
          <option value="${pair[1]}" ${storedResult === pair[1] ? "selected" : ""}>${pair[1]}</option>
        </select>
      </label>
    `;
    container.appendChild(match);
  });
}

function loadLeaderboard() {
  const container = document.getElementById('leaderboard');
  if (!container) return;

  const standings = {};
  teams.forEach(team => standings[team] = 0);

  matches.forEach((pair, index) => {
    const result = localStorage.getItem(`match-result-${index}`);
    if (result && standings[result] !== undefined) {
      standings[result]++;
    }
  });

  const sorted = Object.entries(standings).sort((a, b) => b[1] - a[1]);

  const table = document.createElement('table');
  table.innerHTML = `
    <tr><th>Team</th><th>Wins</th></tr>
    ${sorted.map(([team, score]) => `<tr><td>${team}</td><td>${score}</td></tr>`).join('')}
  `;
  container.appendChild(table);
}

document.addEventListener('DOMContentLoaded', () => {
  loadMatches();
  loadLeaderboard();
});

document.addEventListener('change', e => {
  if (e.target.id.startsWith('match-result-')) {
    const index = e.target.id.split('-')[2];
    localStorage.setItem(`match-result-${index}`, e.target.value);
  }
  if (e.target.id.startsWith('match-date-')) {
    const index = e.target.id.split('-')[2];
    localStorage.setItem(`match-date-${index}`, e.target.value);
  }
});